<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_SQL = new WDK_SQL;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    header ("location: /user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {

        $sql_connection = $WDK_SQL->GetConnection ();

        if ($AccountQueryResult["MailVerified"] == "0")
        {
            if ($AccountQueryResult["MailAddress"] != "")
            {
                $WDK_SQL->Update_Data ($sql_connection, "User_Base", array("username" => $_COOKIE["rep_username"]), array("MailAddress" => ""));
                $WDK_SQL->Update_Data ($sql_connection, "User_Base", array("username" => $_COOKIE["rep_username"]), array("MailVerified" => "0"));
                $WDK_SQL->Delete_Data ($sql_connection, "System_MailCode", array("username" => $_COOKIE["rep_username"]));

                $Web_Tools->WEBWarn ("成功解绑暂未验证的邮箱", "登录界面", "/user/login");
            }
            else
            {
                $Web_Tools->WEBWarn ("您还没绑定邮箱呢", "面板", "/user/panel");
            }
        }
        else
        {
            $RandCode = rand ("100000000", "999999999");

            $WDK_SQL->Delete_Data (
                $sql_connection,
                "System_MailCode",
                array(
                    "username" => $_COOKIE["rep_username"]
                )
            );
            $sqls_Mail = "INSERT INTO System_MailCode (code, username) VALUES ('" . $RandCode . "', '" . $_COOKIE["rep_username"] . "')";

            if ($sql_connection->query ($sqls_Mail) === TRUE)
            {
                $Mail_Request = json_decode (file_get_contents ("https://api.atomunite.cn/service/mail/requestSendCode?client_id=c9188138&subject=REPhigrOS邮箱解绑&to=" . $AccountQueryResult["MailAddress"] . "&to_name=" . $_COOKIE["rep_username"] . "&content=您正在解绑邮箱，您的邮箱验证地址为：https://account.rephigros.top/user/app/mailUnlinkVerify?code=" . $RandCode), true);
                if ($Mail_Request["status"])
                {
                    $Web_Tools->WEBWarn ("解绑需要邮箱验证，已发送验证邮件到您的邮箱", "主界面", "/");
                }
                else
                {
                    // var_dump ($Mail_Request);
                    $Web_Tools->WEBWarn ("邮箱发送时发生错误", "登录界面", "/user/login");
                }
            }
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}
?>