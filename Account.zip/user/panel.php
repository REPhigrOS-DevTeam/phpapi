<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_SQL = new WDK_SQL;
$Account_Tools = new REPhigrOS_Account;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    header ("location: /user/login");
}
else
{
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
        {
            $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}
?>

<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 用户面板</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Large-Box">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">用户面板</a></div>
        <hr>
        <div class="Content">
            <a class="Text">用户名：
                <?php echo $_COOKIE["rep_username"]; ?> <a class="Text" href="/user/logout">退出登录</a>
            </a><br>
            <a class="Text">注册时间：
                <?php echo date ("Y-m-d H:i:s", $AccountQueryResult["reg_date"]); ?>
            </a><br>
            <a class="Text">邮箱绑定状态：
                <?php
                if ($AccountQueryResult["MailVerified"] == 1)
                {
                    echo "已绑定（" . $AccountQueryResult["MailAddress"] . "）";
                }
                else
                {
                    if ($AccountQueryResult["MailAddress"] != "")
                    {
                        echo "未验证";
                    }
                    else
                    {
                        echo "未绑定 <a href='/user/setMail'>立即绑定邮箱</a>";
                    }
                }
                ?> <a href="/user/unlinkMail">填错了邮箱或需要解绑？点我解除绑定</a>
            </a><br>
            <b><a class="Text">REPhigrOS 主频道权限：
                    <?php if ($AccountQueryResult["MainGroupAccess"])
                    {
                        echo "拥有</b> （频道号：6fvn2t2469），请务必入频";
                    } ?>
                    <?php
                    if ($AccountQueryResult["MainGroupAccess"])
                    {
                        if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
                        {
                            $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
                        }
                    }
                    else
                    {
                        $sql_connection = $WDK_SQL->GetConnection ();
                        $sqls = "SELECT * FROM Qs_TestAccess WHERE (username='{$_COOKIE["rep_username"]}')";
                        $QueryResult = $sql_connection->query ($sqls);
                        $Repeat = FALSE;
                        if ($QueryResult->num_rows > 0)
                        {
                            while ($user = $QueryResult->fetch_assoc ())
                            {
                                if ($user["opening"] == 1)
                                {
                                    $Repeat = TRUE;
                                }
                            }
                        }
                        if ($Repeat)
                        {
                            echo '审核中</a> <a class="Text" style="color: red;">您已经提交，等待审核中（如果此状态消失，说明没有过审）</a></b>';
                        }
                        else
                        {
                            echo '未拥有</a> <a class="Text" href="/user/app/ask">申请主频道进入权限</a></b>';
                        }
                    }
                    ?>
                    <br>
                    <!-- <a class="Text"
                        style="color: red; font-size: 90%;">现在已经获得入频和内测权限，但是未入QQ频道的玩家，请尽快入频（！否则将没有下载途径！）</a><br> -->
                    <b><a class="Text">REPhigrOS 2.0 内测游玩权限：
                            <?php if ($User_TestAccess["TestingPermissions"])
                            {
                                echo "拥有";
                            }
                            else
                            {
                                echo "未拥有 <a href='/user/app/beta'>点我获取权限</a>";
                                // echo "未拥有 <a style='color: red;'>暂未开放测试</a>";
                            } ?>
                        </a></b><br>
                    <?php
                    if ($User_TestAccess["CountStampA"] >= time ())
                    {

                        $PassTimeB = $User_TestAccess["CountStampA"] - time ();
                        if ($PassTimeB <= 60)
                        {
                            $PassTimeB = $PassTimeB + " 秒";
                        }
                        else
                        {
                            if ($PassTimeB <= 3600)
                            {
                                $PassTimeB = intval ($PassTimeB / 60) . " 分";
                            }
                            else
                            {
                                if ($PassTimeB <= 86400)
                                {
                                    $PassTimeB = intval ($PassTimeB / 60 / 24) . " 小时";
                                }
                                else
                                {
                                    $PassTimeB = intval ($PassTimeB / 60 / 60 / 24) . " 天";
                                }
                            }
                        }
                    }
                    else
                    {
                        $PassTimeB = "现在可以登录";
                    }

                    if ($User_TestAccess["CountStampB"] >= time ())
                    {
                        $RemainingTimeB = $User_TestAccess["CountStampB"] - time ();
                        if ($RemainingTimeB <= 60)
                        {
                            $RemainingTimeB = $RemainingTimeB + " 秒";
                        }
                        else
                        {
                            if ($RemainingTimeB <= 3600)
                            {
                                $RemainingTimeB = intval ($RemainingTimeB / 60) . " 分";
                            }
                            else
                            {
                                if ($RemainingTimeB <= 86400)
                                {
                                    $RemainingTimeB = intval ($RemainingTimeB / 60 / 24) . " 小时";
                                }
                                else
                                {
                                    $RemainingTimeB = intval ($RemainingTimeB / 60 / 60 / 24) . " 天";
                                }
                            }
                        }
                    }
                    else
                    {
                        $RemainingTimeB = "现在可以登录";
                    }
                    if ($User_TestAccess["TestingPermissions"])
                    {
                        echo '<a class="Text">设备一（下次登录所需时间）：' . $PassTimeB . '</a><br>';
                        echo '<a class="Text">设备二（下次登录所需时间）：' . $RemainingTimeB . '</a><br>';
                        echo '<a href="/user/reset-ts">> 申请重置下次登录所需时间</a><br><br>';
                    }
                    ?>
                    <br><br>
                    <a class="Text" style="color: red; font-size: 150%">请务必进入频道！只有频道内才有官方下载链接（频道号：6fvn2t2469）</a><br>
                    <a class="Text" style="color: blue;">如果您已经登录上了，就无需再管上面的“下次登录所需时间”，通俗的来讲，那个是登录CD</a><br>
                    <a class="Text" style="color: orange;">只要有一个密钥显示 “现在可以登录” 您就可以登录，如果您想立即消除冷却时间，请联系管理员</a><br><br>
                    <div class="Text" style="float: right;">
                        <a href="//account.rephigros.top/user/issue" target="_blank">反馈问题</a> |
                        <a href="//rephigros.top/tos" target="_blank">服务条款</a> | <a href="//rephigros.top/online"
                            target="_blank">官方多人服务器列表</a>
                    </div>
        </div>
    </section>

    <div class="Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>