<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_SQL = new WDK_SQL;

$sql_connection = $WDK_SQL->GetConnection ();

if (isset($_GET["code"]))
{
    $Data = $WDK_SQL->Fetch_Assoc (
        $WDK_SQL->Find_Data (
            $sql_connection,
            "System_PWDCode",
            array(
                "code" => $_GET["code"]
            )
        )
    );
    if (count ($Data) == 1)
    {
    }
    else
    {
        $Web_Tools->WEBWarn ("无法找到code对应的账户", "主页", "/user/panel");
    }
}
?>

<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 找回您的密码</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Box">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">用户系统</a></div>
        <hr>

        <div class="Content">
            <a class="Text">输入您想在 REPhigrOS 使用的新密码</a><br>
            <form method='post' action='/app/private/resetPWD.php?code=<?php echo $_GET["code"]; ?>'>
                <div>
                    <input class="Input" name="new_password" type="password" placeholder="新密码" required>
                    <br>
                    <input class="Button" type="submit" value="同意服务条款并设置新密码">
                </div>
            </form>
        </div>
    </section>

    <div class="Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
    <div class="Version">
        <a>version: <a id="UserSystemVersion">加载中...</a></a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>