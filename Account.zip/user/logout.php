<?php
header ("Access-Control-Allow-Origin: *");

require("/www/wwwroot/WebSpace/PHP/system.function.php");

$Web_Tools = new REPhigrOS_WebFunction;

// 清除Cookie
setcookie ('rep_username', '', 0, "/", "rephigros.top", true, false);
setcookie ('rep_verifytoken', '', 0, "/", "rephigros.top", true, false);
$Web_Tools->WEBWarn ("退出登录成功", "登录页面", "/user/login");