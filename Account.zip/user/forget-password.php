<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 找回您的密码</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Box">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">用户系统</a></div>
        <hr>

        <div class="Content">
            <a class="Text">使用 REPhigrOS 系统找回您的密码</a><br>
            <form method='post' action='/app/private/user.sign.php?method=reset_password'>
                <div>
                    <input class="Input" name="username" type="text" placeholder="用户名" required>
                    <br>
                    <input class="Button" type="submit" value="同意服务条款并找回密码">
                </div>
            </form>
        </div>
    </section>

    <div class="Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
    <div class="Version">
        <a>version: <a id="UserSystemVersion">加载中...</a></a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>