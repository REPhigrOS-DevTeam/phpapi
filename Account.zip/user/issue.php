<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_SQL = new WDK_SQL;
$Account_Tools = new REPhigrOS_Account;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    header ("location: /user/login");
}
else
{
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
        {
            $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
        }
        else
        {
            /**
             * 建立跳转请求表单
             * @param string $url 数据提交跳转到的URL
             * @param array $data 请求参数数组
             * @param string $method 提交方式：post或get 默认post
             * @return string 提交表单的HTML文本
             */
            function buildRequestForm ($url, $data, $method = 'post')
            {
                $sHtml = "<form id='requestForm' name='requestForm' action='" . $url . "' method='" . $method . "'>";
                foreach ( $data as $key => $val )
                {
                    $sHtml .= "<input type='hidden' name='" . $key . "' value='" . $val . "' />";
                }
                $sHtml = $sHtml . "<input type='submit' value='确定' style='display:none;'></form>";
                $sHtml = $sHtml . "<script>document.forms['requestForm'].submit();</script>";
                return $sHtml;
            }

            $url = 'https://support.qq.com/product/593541';
            $data = array(
                'openid'   => $_COOKIE["rep_username"],
                'nickname' => $_COOKIE["rep_username"],
                'avater'   => 'https://txc.qq.com/static/desktop/img/products/def-product-logo.png'
            );
            echo buildRequestForm ($url, $data);
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}
?>