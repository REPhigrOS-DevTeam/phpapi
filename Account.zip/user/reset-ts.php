<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_SQL = new WDK_SQL;
$Account_Tools = new REPhigrOS_Account;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    header ("location: /user/login");
}
else
{
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
        {
            $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}
?>

<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 申请清空您的Ts时间</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Box">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">申请清空您的Ts时间</a></div>
        <hr>

        <div class="Content">
            <a class="Text">输入您的情况或理由</a><br>
            <form method='post' action='/app/private/resetTs.php'>
                <div>
                    <input class="Input" name="reason" type="text" placeholder="理由" required>
                    <br>
                    <input class="Button" type="submit" value="提交">
                </div>
            </form>
        </div>
    </section>

    <div class="Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
    <div class="Version">
        <a>version: <a id="UserSystemVersion">加载中...</a></a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>