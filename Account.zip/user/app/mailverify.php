<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$Account_Tools = new REPhigrOS_Account;

$SQL_Tools = new SQL_Manage;
$sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

$WDK_SQL = new WDK_SQL;

if (isset($_GET["code"]))
{
    $Data = $WDK_SQL->Fetch_Assoc (
        $WDK_SQL->Find_Data (
            $sql_connection,
            "System_MailCode",
            array(
                "code" => $_GET["code"]
            )
        )
    );
    if (count ($Data) == 1)
    {
        $Data = $Data[0];
        $WDK_SQL->Update_Data (
            $sql_connection,
            "User_Base",
            array(
                "username" => $Data["username"]
            ),
            array(
                "MailVerified" => "1"
            )
        );
        $WDK_SQL->Delete_Data ($sql_connection, "System_MailCode", array("code" => $_GET["code"]));
        $Web_Tools->WEBWarn ("验证成功", "主界面", "/");
    }
    else
    {
        $Web_Tools->WEBWarn ("无法验证邮箱，数据库发生异常", "主界面", "/");
    }
}
else
{
    $Web_Tools->WEBWarn ("无法验证邮箱，没有参数", "主界面", "/");
}

?>