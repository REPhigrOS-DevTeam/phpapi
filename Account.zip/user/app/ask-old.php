<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");

$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    header ("location: /user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
        {
            $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}
?>

<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 审核问卷</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Large-Box-Content">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">审核问卷</a></div>
        <hr>
        <div class="Content">
            <a class="Text">用户名：
                <?php echo $_COOKIE["rep_username"]; ?>
            </a><br>
            <form method='post' action='/app/private/upload.ask.php'>
                <div>
                    <br>
                    <a class="Text">1.进频道后，能做到先看频公告和频规则吗</a><br>
                    <label><input class="radio_type" type="radio" name="Q1" value="1" required> 是 </label>
                    <label><input class="radio_type" type="radio" name="Q1" value="0" required> 否 </label>
                    <br><br>
                    <a class="Text">2.REP频道里没有自制谱，不要找管理要谱子，否则严重者将会被管理员踢出频道。2.0版本后可以在游戏里面挑选下载谱面，你清楚了吗？</a><br>
                    <input class="Input" name="Q2" type="text" placeholder="填 清楚 或 不清楚" required>
                    <br><br>
                    <a class="Text">3.你是否已知晓并能做到模拟器不能外传的规则</a><br>
                    <label><input class="radio_type" type="radio" name="Q3" value="1" required> 是 </label>
                    <label><input class="radio_type" type="radio" name="Q3" value="0" required> 否 </label>
                    <br><br>
                    <a class="Text">4.在子频道开始发言前，能做到先翻一下该子频道的精华消息吗</a><br>
                    <label><input class="radio_type" type="radio" name="Q4" value="1" required> 是 </label>
                    <label><input class="radio_type" type="radio" name="Q4" value="0" required> 否 </label>
                    <br><br>
                    <a class="Text">5.如果违反了频规则就会被警告甚至踢出，可以接受吗？</a><br>
                    <label><input class="radio_type" type="radio" name="Q5" value="1" required> 是 </label>
                    <label><input class="radio_type" type="radio" name="Q5" value="0" required> 否 </label>
                    <br><br>
                    <a class="Text">6.遇到问题，可以先去查看rep常见问题自行尝试解决，无法解决后再提问吗？</a><br>
                    <label><input class="radio_type" type="radio" name="Q6" value="1" required> 是 </label>
                    <label><input class="radio_type" type="radio" name="Q6" value="0" required> 否 </label>
                    <br><br>
                    <a class="Text">7.如果违反了频规则就会被警告甚至踢出，可以接受吗？</a><br>
                    <label><input class="radio_type" type="radio" name="Q7" value="1" required> 是 </label>
                    <label><input class="radio_type" type="radio" name="Q7" value="0" required> 否 </label>
                    <br><br>
                    <a class="Text">8.截至Phigros 3.0.0版本，CROSS SOUL IN难度定数为多少（精确至一位小数）</a><br>
                    <input class="Input" name="Q8" type="text" placeholder="内容" required>
                    <br><br>
                    <a class="Text">9.截止Phigros3.0.0版本，下列谱师中，谁不是Phigros官方谱师？</a><br>
                    <label><input class="radio_type" type="radio" name="Q9" value="1" required> Air </label>
                    <label><input class="radio_type" type="radio" name="Q9" value="2" required> Barbarianerman野从
                    </label>
                    <label><input class="radio_type" type="radio" name="Q9" value="3" required> 198 </label>
                    <label><input class="radio_type" type="radio" name="Q9" value="4" required> Cty村头鱼 </label>
                    <br><br>
                    <a class="Text">10.Phigros中，IN难度全称是什么？</a><br>
                    <label><input class="radio_type" type="radio" name="Q10" value="1" required> INSANE </label>
                    <label><input class="radio_type" type="radio" name="Q10" value="2" required> INSONE </label>
                    <label><input class="radio_type" type="radio" name="Q10" value="3" required> INSAME </label>
                    <label><input class="radio_type" type="radio" name="Q10" value="4" required> DEEPIN </label>
                    <br><br>
                    <a class="Text">11.下列曲目当中，哪一首曲目是玩家俗称的“姐姐砍我”？</a><br>
                    <label><input class="radio_type" type="radio" name="Q11" value="1" required> Destination </label>
                    <label><input class="radio_type" type="radio" name="Q11" value="2" required> Igallta </label>
                    <label><input class="radio_type" type="radio" name="Q11" value="3" required> Spasmodic </label>
                    <label><input class="radio_type" type="radio" name="Q11" value="4" required> FULI AUTO SHOOTER
                    </label>
                    <br><br>
                    <a class="Text">12.Phigros中，CROSS✟SOUL（Hyun精选集，IN难度）的谱师是</a><br>
                    <label><input class="radio_type" type="radio" name="Q12" value="1" required> 阿爽 </label>
                    <label><input class="radio_type" type="radio" name="Q12" value="2" required> 无极 </label>
                    <label><input class="radio_type" type="radio" name="Q12" value="3" required> 198 </label>
                    <label><input class="radio_type" type="radio" name="Q12" value="4" required> 清水QR </label>
                    <br><br>
                    <a class="Text">13.下面哪一首曲子不是Phigros第五章收录曲目？</a><br>
                    <label><input class="radio_type" type="radio" name="Q13" value="1" required> Reimei </label>
                    <label><input class="radio_type" type="radio" name="Q13" value="2" required> NYA！！ </label>
                    <label><input class="radio_type" type="radio" name="Q13" value="3" required> Class Memories </label>
                    <label><input class="radio_type" type="radio" name="Q13" value="4" required> Cryout </label>
                    <br><br>
                    <a class="Text">14.txt文件是属于以下哪种文件类型？</a><br>
                    <label><input class="radio_type" type="radio" name="Q14" value="1" required> 音频文件 </label>
                    <label><input class="radio_type" type="radio" name="Q14" value="2" required> 文本文件 </label>
                    <label><input class="radio_type" type="radio" name="Q14" value="3" required> 图片文件 </label>
                    <label><input class="radio_type" type="radio" name="Q14" value="4" required> 压缩文件 </label>
                    <br><br>
                    <a class="Text">15.是以下哪个是图片文件的后缀？</a><br>
                    <label><input class="radio_type" type="radio" name="Q15" value="1" required> .png </label>
                    <label><input class="radio_type" type="radio" name="Q15" value="2" required> .txt </label>
                    <label><input class="radio_type" type="radio" name="Q15" value="3" required> .php </label>
                    <label><input class="radio_type" type="radio" name="Q15" value="4" required> .mp4 </label>
                    <br><br>
                    <a class="Text">16.以下哪个格式的文件<b>不能</b>被解压缩软件解压？</a><br>
                    <label><input class="radio_type" type="radio" name="Q16" value="1" required> rar </label>
                    <label><input class="radio_type" type="radio" name="Q16" value="2" required> zip </label>
                    <label><input class="radio_type" type="radio" name="Q16" value="3" required> c4 </label>
                    <label><input class="radio_type" type="radio" name="Q16" value="4" required> 7z </label>
                    <br><br>
                    <a class="Text">17.小明找不到REPhigros安装后的数据文件夹，你知道在哪嘛？</a><br>
                    <label><input class="radio_type" type="radio" name="Q17" value="1" required> Tencent文件夹 </label>
                    <label><input class="radio_type" type="radio" name="Q17" value="2" required> Download文件夹 </label>
                    <label><input class="radio_type" type="radio" name="Q17" value="3" required> Android里的Data文件夹
                    </label>
                    <label><input class="radio_type" type="radio" name="Q17" value="4" required> Windows文件夹 </label>
                    <br><br>
                    <a class="Text">18.以下哪个为游戏谱面配置文件？（不包括曲绘和音乐）</a><br>
                    <label><input class="radio_type" type="radio" name="Q18" value="1" required> exe </label>
                    <label><input class="radio_type" type="radio" name="Q18" value="2" required> apk </label>
                    <label><input class="radio_type" type="radio" name="Q18" value="3" required> MIDI </label>
                    <label><input class="radio_type" type="radio" name="Q18" value="4" required> json </label>
                    <br><br>
                    <a class="Text">19.apk和ipa是什么文件？</a><br>
                    <label><input class="radio_type" type="radio" name="Q19" value="1" required> 应用安装包 </label>
                    <label><input class="radio_type" type="radio" name="Q19" value="2" required> 媒体文件 </label>
                    <label><input class="radio_type" type="radio" name="Q19" value="3" required> 应用程序 </label>
                    <label><input class="radio_type" type="radio" name="Q19" value="4" required> 批处理程序 </label>
                    <br><br>
                    <a class="Text">20.要在手机本地移动文件时，正确的步骤是？</a><br>
                    <label><input class="radio_type" type="radio" name="Q20" value="1" required> 新建文件夹 </label>
                    <label><input class="radio_type" type="radio" name="Q20" value="2" required> 分享→转发 </label>
                    <label><input class="radio_type" type="radio" name="Q20" value="3" required> 移动→粘贴 </label>
                    <label><input class="radio_type" type="radio" name="Q20" value="4" required> 压缩→解压 </label>
                    <br><br>
                    <a class="Text">21.下载文件时进度条突然不动，以下哪种方式不可能有效解决问题的是？</a><br>
                    <label><input class="radio_type" type="radio" name="Q21" value="1" required> 重启手机 </label>
                    <label><input class="radio_type" type="radio" name="Q21" value="2" required> 检查手机储存空间是否充足 </label>
                    <label><input class="radio_type" type="radio" name="Q21" value="3" required> 切换WiFi/移动数据/飞行模式
                    </label>
                    <label><input class="radio_type" type="radio" name="Q21" value="4" required> 砸掉您尊贵的手机 </label>
                    <br><br>
                    <a class="Text">22.如果在使用模拟器时遇到了问题，哪种方法会显得你很diner（低能）</a><br>
                    <label><input class="radio_type" type="radio" name="Q22" value="1" required> 询问其他同样问题但已经解决的频友
                    </label>
                    <label><input class="radio_type" type="radio" name="Q22" value="2" required> 在B站查找教程 </label>
                    <label><input class="radio_type" type="radio" name="Q22" value="3" required> 百度一下 </label>
                    <label><input class="radio_type" type="radio" name="Q22" value="4" required>
                        和低智商人员一样不先尝试寻找办法就在频里四处问人 </label>
                    <br><br>
                    <a class="Text">Contact.您的频道昵称和QQ号</a><br>
                    <input class="Input" name="Contact" type="text" placeholder="内容" required>
                    <br><br>
                    <input class="Button" type="submit" value="提交问卷">
                </div>
            </form>
        </div>
    </section>

    <div class="Head-Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>