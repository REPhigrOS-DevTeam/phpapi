<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");

$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    header ("location: /user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
        {
            $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }

    if ($User_TestAccess["TestingPermissions"])
    {
        $Web_Tools->WEBWarn ("您已拥有 RPGR 游玩权限<br>请不要重复获取", "面板", "/");
    }
}
?>

<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 游玩前须知</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Large-Box-Content">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">获得游玩权限前须知</a></div>
        <hr>
        <div class="Content">
            <a class="Text">用户名：
                <?php echo $_COOKIE["rep_username"]; ?>
            </a><br>
            <p>感谢您对 REPhigrOS 的支持！我们移除了多次审核的机制，这使得您游玩 RE:Phigros 的周期缩短，接下来... 您只需要做出承诺</p>
            <p>我们需要您同意我们的 <a href="//rephigros.top/tos" target="_blank">服务条款</a>，这是当然需要的...</p>
            <p>您还需要知道如何导入您的谱面以游玩，谱面的导入教程频道内的有，非常简单，只需动动手指就能学会</p>
            <p>除此之外，您需要知道我们的 <a href="//rephigros.top/online"
                    target="_blank">官方服务器列表</a>，这些是RPGR官方提供的服务器，如果您想和朋友一起游玩，先看看服务器ip就是了</p>
            <p style="color: red;">最后！RPGR 社区/模拟器 所有相关安装包和链接严禁外传、贩卖！</p>
            <a class="Button" href="/app/private/agree.beta">我已知晓并同意 REPhigrOS Team 制定的所有条款，开启 RPGR 之旅！</a>
        </div>
    </section>

    <div class="Head-Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>