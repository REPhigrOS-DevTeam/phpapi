<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");

$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    header ("location: /user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
        {
            $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}
?>

<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 内测激活</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Large-Box-Content">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">内测激活</a></div>
        <hr>
        <div class="Content">
            <a class="Text">用户名：
                <?php echo $_COOKIE["rep_username"]; ?>
            </a><br>
            <form method='post' action='/app/private/upload.beta.php'>
                <div>
                    <br>
                    <a class="Text">请输入您的邀请码</a><br>
                    <input class="Input" name="InviteCode" type="text" placeholder="邀请码" required>
                    <br><br>
                    <input class="Button" type="submit" value="提交">
                </div>
            </form>
        </div>
    </section>

    <div class="Head-Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>