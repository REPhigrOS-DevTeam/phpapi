<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$Account_Tools = new REPhigrOS_Account;
$WDK_SQL = new WDK_SQL;

$SQL_Tools = new SQL_Manage;
$sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

if (isset($_GET["method"], $_POST["username"]))
{

    // 检测 SQL Connection
    if ($sql_connection->connect_error)
    {
        $Status = false;
    } else
    {
        $Status = true;
    }

    $WordBanlist = [
        "sb",
        "cnm",
        "fuck",
        "CNM",
        "FUCK",
        "xijinping"
    ];

    if ($Status)
    {
        switch ($_GET["method"])
        {
            case "websiteLogin":

                $user = $WDK_SQL->Fetch_Assoc ($WDK_SQL->Find_Data ($sql_connection, "User_Base", array("username" => $_POST["username"])));

                if (count ($user) == 1)
                {
                    $user = $user[0];
                    if (isset($_POST["userpassword"]))
                    {
                        if ($user["usertoken"] == $Account_Tools->getUserToken ($_POST["userpassword"]))
                        {
                            setcookie ('rep_username', $_POST["username"], time () + 7 * 24 * 60 * 60, "/", "atomunite.cn", true, false);
                            setcookie ('rep_verifytoken', $user["userverifytoken"], time () + 7 * 24 * 60 * 60, "/", "atomunite.cn", true, false);

                            $Web_Tools->WEBWarn ("登录账户成功", "主页", "/user/panel");
                        } else
                        {
                            $Web_Tools->WEBWarn ("用户名或密码错误", "登录界面", "/user/login");
                        }
                    } else
                    {
                        $Web_Tools->WEBWarn ("参数不完整", "登录界面", "/user/login");
                    }
                } else
                {
                    $Web_Tools->WEBWarn ("系统错误或用户名不存在", "登录界面", "/user/login");
                }

                $sql_connection->close ();
                break;

            case "websiteRegister":

                if (ctype_alnum ($_POST["username"]) && ctype_alnum ($_POST["userpassword"]))
                {

                    if (isset($_POST["mail"]))
                    {
                        $sqls = "SELECT * FROM User_Base WHERE (username='{$_POST["username"]}')";
                        $QueryResult = $sql_connection->query ($sqls);

                        if ($QueryResult->num_rows > 0)
                        {
                            $Web_Tools->WEBWarn ("用户名已被注册", "注册界面", "/user/register");
                        } else
                        {

                            $Ban = false;
                            $Word = false;

                            foreach ( $WordBanlist as $key => $value )
                            {
                                if (strpos ($_POST["username"], $value) !== false)
                                {
                                    $Ban = true;
                                    $Word = $value;
                                }
                            }

                            $length = mb_strlen ($_POST["username"]);

                            if ($length < 30)
                            {
                                if (! $Ban)
                                {
                                    $MailBanlist = $WDK_SQL->Fetch_Assoc ($WDK_SQL->Find_Data ($sql_connection, "Record_MailBannedList", array("Email" => $_POST["mail"])));
                                    if (count ($MailBanlist) == 0)
                                    {
                                        $userToken = $Account_Tools->getUserToken ($_POST["userpassword"]);
                                        $userNewVerifyToken = $Account_Tools->GetRandStr (32);
                                        $Time = time ();


                                        // USERDATA

                                        $sqls_userdata = "INSERT INTO User_Base (username, usertoken, userverifytoken, MailAddress, MailVerified, MainGroupAccess, Level_group, banned, reg_date) VALUES ('{$_POST["username"]}', '{$userToken}', '{$userNewVerifyToken}', '" . $_POST["mail"] . "', '0', '0', '0', '0', {$Time})";


                                        // REP_APPTOKEN

                                        $RandStr1 = $Account_Tools->GetRandStr (128);
                                        $RandStr2 = $Account_Tools->GetRandStr (128);

                                        $sqls_appToken = "INSERT INTO User_TestAccess (username, TestingPermissions, VerifyJSON, CountStampA, CountStampB, userTSVerifyTokenA, userTSVerifyTokenB) VALUES ('{$_POST["username"]}', '0', '{}', '{$Time}', '{$Time}', '{$RandStr1}', '{$RandStr2}')";

                                        $RandCode = rand ("100000000", "999999999");

                                        $sqls_Mail = "INSERT INTO System_MailCode (code, username) VALUES ('" . $RandCode . "', '" . $_POST["username"] . "')";

                                        if ($sql_connection->query ($sqls_Mail) === TRUE)
                                        {
                                            $Mail_Request = json_decode (file_get_contents ("https://api.atomunite.cn/service/mail/requestSendCode?client_id=c9188138&subject=REPhigrOS邮箱验证&to=" . $_POST["mail"] . "&to_name=" . $_POST["username"] . "&content=您的邮箱验证地址为：https://account.rephigros.top/user/app/mailverify?code=" . $RandCode), true);
                                            if ($Mail_Request["status"])
                                            {
                                            } else
                                            {
                                                $Web_Tools->WEBWarn ("邮箱发送时发生错误", "登录界面", "/user/login");
                                            }
                                        } else
                                        {
                                            $Web_Tools->WEBWarn ("数据库写入时发生错误", "登录界面", "/user/login");
                                        }

                                        if ($sql_connection->query ($sqls_userdata) === TRUE && $sql_connection->query ($sqls_appToken) === TRUE)
                                        {

                                            setcookie ('rep_username', $_POST["username"], time () + 7 * 24 * 60 * 60, "/", "rephigros.top", true, false);
                                            setcookie ('rep_verifytoken', $userNewVerifyToken, time () + 7 * 24 * 60 * 60, "/", "rephigros.top", true, false);

                                            $Web_Tools->WEBWarn ("注册成功，请注意查收邮件并验证您的邮箱", "主页", "/user/panel");
                                        } else
                                        {
                                            $Web_Tools->WEBWarn ("数据库发生错误{$sql_connection->error}", "登录界面", "/user/login");
                                        }
                                    } else
                                    {
                                        $Web_Tools->WEBWarn ("您的邮箱已被封禁", "主页", "/user/panel");
                                    }
                                } else
                                {
                                    $Web_Tools->WEBWarn ("您的账户有敏感词", "主页", "/user/panel");
                                }
                            } else
                            {
                                $Web_Tools->WEBWarn ("用户名长度不能超过 30", "主页", "/user/panel");
                            }
                        }
                    } else
                    {
                        $Web_Tools->WEBWarn ("未查询到邮箱输入", "主页", "/user/panel");
                    }
                } else
                {
                    $Web_Tools->WEBWarn ("用户名和密码只允许使用英文和数字组合", "登录界面", "/user/login");
                }

                $sql_connection->close ();
                break;
            case "reset_password":
                header ("content-type:application/json");
                $Result = $Account_Tools->getAccountUserDataWithNoPW ($_POST["username"]);

                if (isset($Result["MailAddress"]) && $Result["MailAddress"] != "" && $Result["MailVerified"] == "1")
                {
                    if ($Result != false)
                    {
                        $RAND_CODE = $Account_Tools->GetRandStr (10);
                        $sqls = "INSERT INTO System_PWDCode (code, username) VALUES ('" . $RAND_CODE . "', '" . $_POST["username"] . "')";

                        if ($sql_connection->query ($sqls) === TRUE)
                        {
                            $result = json_decode (file_get_contents ("https://api.atomunite.cn/service/mail/requestSendCode?client_id=c9188138&subject=重置密码|REPhigrOS-官方&to=" . $Result["MailAddress"] . "&to_name=" . $_POST["username"] . "&content=您的更改密码地址为：https://account.rephigros.top/user/reset-password?code=" . $RAND_CODE), true);
                            if ($result["status"])
                            {
                                $Web_Tools->WEBWarn ("请查看您的邮箱来重置密码", "主页", "/");
                            } else
                            {
                                $Web_Tools->WEBWarn ("发送邮件失败，邮件服务器故障：" . $result["msg"], "主页", "/");
                            }
                        } else
                        {
                            $Web_Tools->WEBWarn ("数据库发生错误{$sql_connection->error}", "主页", "/");
                        }

                        $sql_connection->close ();
                        break;
                    } else
                    {
                        $Web_Tools->WEBWarn ("无法找到此用户", "主页", "/");
                    }
                } else
                {
                    $Web_Tools->WEBWarn ("您尚未绑定邮箱，请联系管理员解决", "主页", "/");
                }
                break;
        }
    }
} else
{
    echo json_encode (
        array(
            "status" => false,
            "msg" => "无法解析您的请求"
        )
    );
}