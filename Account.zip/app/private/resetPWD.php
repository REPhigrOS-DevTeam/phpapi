<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_SQL = new WDK_SQL;

$sql_connection = $WDK_SQL->GetConnection ();

if (isset($_GET["code"], $_POST["new_password"]))
{
    $Data = $WDK_SQL->Fetch_Assoc (
        $WDK_SQL->Find_Data (
            $sql_connection,
            "System_PWDCode",
            array(
                "code" => $_GET["code"]
            )
        )
    );
    if (count ($Data) == 1)
    {
        $Data = $Data[0];
        $WDK_SQL->Update_Data (
            $sql_connection,
            "User_Base",
            array(
                "username" => $Data["username"]
            ),
            array(
                "usertoken" => base64_encode (sha1 (md5 ($_POST["new_password"])))
            )
        );
        $WDK_SQL->Delete_Data ($sql_connection, "System_PWDCode", array("code" => $_GET["code"]));
        $Web_Tools->WEBWarn ("成功修改您的密码", "主页", "/user/panel");
    }
    else
    {
        $Web_Tools->WEBWarn ("无法找到code对应的账户", "主页", "/user/panel");
    }
}
?>