<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_Web = new WDK_Web;
$WDK_SQL = new WDK_SQL;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    $Web_Tools->Jump ("/user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}

if (isset($_POST["InviteCode"]))
{
    $SQL_Connection = $WDK_SQL->GetConnection ();

    $CheckResult_Object = $WDK_SQL->Find_Data ($SQL_Connection, "Record_TestAccessInviteList", array("UserName" => $_COOKIE["rep_username"]));
    $CheckResult = $WDK_SQL->Fetch_Assoc ($CheckResult_Object);

    if (count ($CheckResult) != 0)
    {
        $CheckResult = $CheckResult[0];
        if ($CheckResult["Used"] == 0)
        {
            if ($_POST["InviteCode"] == $CheckResult["Code"])
            {
                $WDK_SQL->Update_Data ($SQL_Connection, "User_TestAccess", array("username" => $_COOKIE["rep_username"]), array("TestingPermissions" => 1));
                $WDK_SQL->Update_Data ($SQL_Connection, "User_TestAccess", array("username" => $_COOKIE["rep_username"]), array("CountStampA" => "0"));
                $WDK_SQL->Update_Data ($SQL_Connection, "User_TestAccess", array("username" => $_COOKIE["rep_username"]), array("CountStampB" => "0"));
                $WDK_SQL->Update_Data ($SQL_Connection, "Record_TestAccessInviteList", array("username" => $_COOKIE["rep_username"]), array("Used" => 1));
                $Web_Tools->WEBWarn ("成功接受邀请！", "面板", "/user/panel");
            }
            else
            {
                $Web_Tools->WEBWarn ("邀请码错误，或用户名称不对应", "面板", "/user/panel");
            }
        }
        else
        {
            $Web_Tools->WEBWarn ("您已经接受过邀请，如果您没有RPGR 游玩权限，则可能被管理组撤销了权限", "面板", "/user/panel");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("您尚未获得邀请", "面板", "/user/panel");
    }
}