<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");

if (isset($_POST["Q1"], $_POST["Q2"], $_POST["Q3"], $_POST["Q4"], $_POST["Q5"], $_POST["Q6"], $_POST["Q7"], $_POST["Q8"], $_POST["Q9"], $_POST["Q10"], $_POST["Q11"], $_POST["Q12"], $_POST["Q13"], $_POST["Q14"], $_POST["Q15"], $_POST["Q16"], $_POST["Q17"], $_POST["Q18"], $_POST["Q19"], $_POST["Q20"], $_POST["Q21"], $_POST["Q22"], $_POST["Contact"], $_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{

    $Web_Tools = new REPhigrOS_WebFunction;
    $Account_Tools = new REPhigrOS_Account;

    $SQL_Tools = new SQL_Manage;
    $sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

    // 检测 SQL Connection
    if ($sql_connection->connect_error)
    {
        $Status = false;
    }
    else
    {
        $Status = true;
    }

    $sqls = "SELECT * FROM Qs_TestAccess WHERE (username='{$_COOKIE["rep_username"]}')";
    $QueryResult = $sql_connection->query ($sqls);
    $Repeat = FALSE;
    if ($QueryResult->num_rows > 0)
    {
        while ($user = $QueryResult->fetch_assoc ())
        {
            if ($user["opening"] == 1)
            {
                $Repeat = TRUE;
            }
        }
    }
    if ($Repeat)
    {
        $Web_Tools->WEBWarn ("您不能重复提交问卷", "首页", "/index.php");
    }
    else
    {
        $Array = array(
            "Q1"  => $_POST["Q1"],
            "Q2"  => $Web_Tools->stringToUnicode ($_POST["Q2"]),
            "Q3"  => $_POST["Q3"],
            "Q4"  => $_POST["Q4"],
            "Q5"  => $_POST["Q5"],
            "Q6"  => $_POST["Q6"],
            "Q7"  => $_POST["Q7"],
            "Q8"  => $Web_Tools->stringToUnicode ($_POST["Q8"]),
            "Q9"  => $_POST["Q9"],
            "Q10" => $_POST["Q10"],
            "Q11" => $_POST["Q11"],
            "Q12" => $_POST["Q12"],
            "Q13" => $_POST["Q13"],
            "Q14" => $_POST["Q14"],
            "Q15" => $_POST["Q15"],
            "Q16" => $_POST["Q16"],
            "Q17" => $_POST["Q17"],
            "Q18" => $_POST["Q18"],
            "Q19" => $_POST["Q19"],
            "Q20" => $_POST["Q20"],
            "Q21" => $_POST["Q21"],
            "Q22" => $_POST["Q22"],
        );
        $Array = json_encode ($Array);

        $RandStr1 = $Account_Tools->GetRandStr (12);

        $sqls = "INSERT INTO Qs_TestAccess (PaperID, opening, AnswerJSON, username, contact) VALUES ('{$RandStr1}', '1', '{$Array}', '{$_COOKIE["rep_username"]}', '{$_POST["Contact"]}')";
        $QueryResult = $sql_connection->query ($sqls);

        $Web_Tools->WEBWarn ("上传完毕", "首页", "/index.php");
    }
}
else
{
    echo "LOST";
}