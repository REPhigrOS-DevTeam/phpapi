<?
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_SQL = new WDK_SQL;
$Account_Tools = new REPhigrOS_Account;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    header ("location: /user/login");
}
else
{
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if (! $Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
        {
            if (isset($_POST["reason"]))
            {
                $SQL_Connection = $WDK_SQL->GetConnection ();
                $WDK_SQL->Add_Data (
                    $SQL_Connection,
                    "Qs_ClearTs",
                    array(
                        "name"   => $_COOKIE["rep_username"],
                        "reason" => $_POST["reason"]
                    )
                );
                $Web_Tools->WEBWarn ("已提交您的申请", "面板", "/");
            }
            else
            {
                $Web_Tools->WEBWarn ("提交参数不全", "面板", "/");
            }
        }
        else
        {
            $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}
?>