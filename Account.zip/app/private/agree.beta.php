<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_Web = new WDK_Web;
$WDK_SQL = new WDK_SQL;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    $Web_Tools->Jump ("/user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);

    if ($AccountQueryResult != false)
    {
        if ($AccountQueryResult["MainGroupAccess"] == 1)
        {
            $SQL_Connection = $WDK_SQL->GetConnection ();

            $WDK_SQL->Update_Data ($SQL_Connection, "User_TestAccess", array("username" => $_COOKIE["rep_username"]), array("TestingPermissions" => 1));
            $WDK_SQL->Update_Data ($SQL_Connection, "User_TestAccess", array("username" => $_COOKIE["rep_username"]), array("CountStampA" => "0"));
            $WDK_SQL->Update_Data ($SQL_Connection, "User_TestAccess", array("username" => $_COOKIE["rep_username"]), array("CountStampB" => "0"));

            $Web_Tools->WEBWarn ("成功获得游玩 RPGR 的权限！<br>您现已可以使用 RPGR 账户登录游戏", "面板", "/user/panel");
        }
        else
        {
            $Web_Tools->WEBWarn ("您需要先获得入频权限", "面板", "/user/panel");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}