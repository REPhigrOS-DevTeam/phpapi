<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");

$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    $Web_Tools->Jump ("/user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($AccountQueryResult["Level_group"] >= 5)
        {
            if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
            {
                $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
            }
        }
        else
        {
            $Web_Tools->Jump ("/index.php");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}

$SQL_Tools = new SQL_Manage;
$sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

// 检测 SQL Connection
if ($sql_connection->connect_error)
{
    $Status = false;
}
else
{
    $Status = true;
}
?>

<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 审核页</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
    <link rel="stylesheet" href="//cdn.staticfile.org/github-markdown-css/5.2.0/github-markdown-light.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Large-Box-Content markdown-body">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">审核</a> <a class="SubTitle"
                href="/app/admin/shenhe.php">刷新页面</a></div>
        <hr>
        <div class="Content">
            <a class="Text">您的用户名：
                <?php echo $_COOKIE["rep_username"]; ?>
            </a><br>
            <a class="Text">等待审核用户：</a><br>
            <?php
            $sqls = "SELECT * FROM Qs_TestAccess";
            $QueryResult = $sql_connection->query ($sqls);
            while ($Paper = $QueryResult->fetch_assoc ())
            {
                echo '
                            <div class="BlockCard">
                                <div class="ContentBox">
                                    <h2>' . $Paper["username"] . '</h2>
                                    <p><a href="/app/admin/paper.php?paperid=' . $Paper["PaperID"] . '" style="text-decoration: none !important;">进行审核</a></p>
                                </div>
                            </div>
                    ';
                // echo '<a class="Button" href="/app/admin/paper.php?paperid=' . $Paper["PaperID"] . '">' . $Paper["username"] . '</a><br>';
            }
            ?>
        </div>
        <div class="Content">
            <a class="Text">Ts消除等待审核用户：</a><br>
            <?php
            $sqls = "SELECT * FROM Qs_ClearTs";
            $QueryResult = $sql_connection->query ($sqls);
            while ($Ts = $QueryResult->fetch_assoc ())
            {
                echo '
                            <div class="BlockCard">
                                <div class="ContentBox">
                                    <h2>' . $Ts["name"] . '</h2>
                                    <p>原因：' . $Ts["reason"] . '</p>
                                    <p><a href="/app/admin/controler/ChangeUserTs.php?Name=' . $Ts["name"] . '" style="text-decoration: none !important;">通过</a></p>
                                </div>
                            </div>
                    ';
            }
            ?>
        </div>
        <!-- <br><br>
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">RPGR 游玩码发放系统</a></div>
        <hr>
        <div class="Content">
            <a class="Text">您的用户名：
                <?php
                // echo $_COOKIE["rep_username"];
                ?>
            </a><br>
            <form method='post' action='/app/admin/controler/CreateInviteCode.php'>
                <div>
                    <input class="Input" name="invitename" type="text" placeholder="用户名" required>
                    <br>
                    <input class="Button" type="submit" value="生成一个邀请码">
                </div>
            </form>
        </div> -->
        <br><br>
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">查询用户入频权限</a></div>
        <hr>
        <div class="Content">
            <form method='post' action='/app/admin/controler/SearchUserAccess.php'>
                <div>
                    <input class="Input" name="name" type="text" placeholder="用户名" required>
                    <br>
                    <input class="Button" type="submit" value="查询">
                </div>
            </form>
        </div>
        <br><br>
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">撤销用户入频权限</a></div>
        <hr>
        <div class="Content">
            <form method='post' action='/app/admin/controler/RemoveUserAccess.php'>
                <div>
                    <input class="Input" name="name" type="text" placeholder="用户名" required>
                    <br>
                    <input class="Button" type="submit" value="撤销">
                </div>
            </form>
        </div>
        <br><br>
        <!-- <div><a class="Title">REPhigrOS</a><a class="SubTitle">封禁用户</a></div>
        <hr>
        <div class="Content">
            <form method='post' action='/app/admin/controler/BanUser.php'>
                <div>
                    <input class="Input" name="name" type="text" placeholder="用户名" required>
                    <br>
                    <input class="Button" type="submit" value="封禁">
                </div>
            </form>
        </div>
        <br><br> -->
        <?php
        if ($AccountQueryResult["Level_group"] >= 8)
        {
            echo '
            <div><a class="Title">审核添加</a><a class="SubTitle" style="color: red;">添加一位新审核（高危）</a></div>
            <hr>
            <div class="Content">
                <form method="post" action="/app/admin/controler/AddAuditor.php">
                    <div>
                        <input class="Input" name="invitename" type="text" placeholder="用户名" required>
                        <br>
                        <input class="Button" type="submit" value="添加">
                    </div>
                </form>
            </div>
            <br><br>
            <div><a class="Title">审核删除</a><a class="SubTitle">删除一位新审核</a></div>
            <hr>
            <div class="Content">
                <form method="post" action="/app/admin/controler/RemoveAuditor.php">
                    <div>
                        <input class="Input" name="invitename" type="text" placeholder="用户名" required>
                        <br>
                        <input class="Button" type="submit" value="删除">
                    </div>
                </form>
            </div>
            ';
        }
        ?>

    </section>

    <div class="Head-Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>