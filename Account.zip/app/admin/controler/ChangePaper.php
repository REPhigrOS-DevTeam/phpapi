<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");

$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    $Web_Tools->Jump ("/user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($AccountQueryResult["Level_group"] >= 5)
        {
            if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
            {
                $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
            }
        }
        else
        {
            $Web_Tools->Jump ("/index.php");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}

$SQL_Tools = new SQL_Manage;
$sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

// 检测 SQL Connection
if ($sql_connection->connect_error)
{
    $Status = false;
}
else
{
    $Status = true;
}

if (isset($_GET["paperid"], $_GET["agree"]))
{
    $sqls = "SELECT * FROM Qs_TestAccess WHERE (PaperID='{$_GET["paperid"]}')";
    $QueryResult = $sql_connection->query ($sqls);
    if ($QueryResult->num_rows > 0)
    { // 检查 Query Result
        $user = $QueryResult->fetch_assoc ();

        $sqlsDELETE = "DELETE FROM Qs_TestAccess WHERE PaperID='{$_GET["paperid"]}'";

        // 判断 Agree
        if ($_GET["agree"] == "true")
        {
            $QueryResult = $sql_connection->query ("UPDATE User_Base SET MainGroupAccess = '1' WHERE `User_Base`.`username` = '{$user["username"]}'");
            $QueryResultDelete = $sql_connection->query ($sqlsDELETE);
        }
        else
        {
            if ($_GET["agree"] == "false")
            {
                $QueryResultDelete = $sql_connection->query ($sqlsDELETE);
            }
        }
    }
    else
    {
        $Web_Tools->Jump ("/app/admin/shenhe.php");
    }
}
else
{
    $Web_Tools->Jump ("/app/admin/shenhe.php");
}

mysqli_close ($sql_connection);
$Web_Tools->Jump ("/app/admin/shenhe.php");