<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$WDK_Web = new WDK_Web;
$WDK_SQL = new WDK_SQL;
$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    $Web_Tools->Jump ("/user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($AccountQueryResult["Level_group"] >= 5)
        {
            if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
            {
                $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
            }
        }
        else
        {
            $Web_Tools->Jump ("/index.php");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}

$SQL_Tools = new SQL_Manage;
$sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

if (isset($_POST["invitename"]))
{
    $AccResult = $WDK_SQL->Fetch_Assoc (
        $WDK_SQL->Find_Data (
            $sql_connection,
            "Record_TestAccessInviteList",
            array(
                "UserName" => $_POST["invitename"]
            )
        )
    );

    if (isset($AccResult[0]))
    {
        $AccResult = $AccResult[0];
        $Code = $AccResult["Code"];
        $Web_Tools->WEBWarn ("已邀请过，邀请码：" . $Code . "<br>被邀请人名称：" . $AccResult["UserName"] . "<br>邀请人：" . $AccResult["GenerateBy"], "审核界面", "/app/admin/shenhe.php");
    }
    else
    {
        $Code = $WDK_Web->GetRandStr (8);
        $WDK_SQL->SendQuery ($sql_connection, "INSERT INTO Record_TestAccessInviteList (UserName, Code, Used, GenerateBy) VALUES ('" . $_POST["invitename"] . "', '" . $Code . "', '0', '" . $_COOKIE["rep_username"] . "')");
        $Web_Tools->WEBWarn ("成功，邀请码：" . $Code . "<br>被邀请人名称：" . $_POST["invitename"] . "<br>邀请人：" . $_COOKIE["rep_username"], "审核界面", "/app/admin/shenhe.php");
    }
}
else
{
    $Web_Tools->Jump ("/app/admin/shenhe.php");
}
mysqli_close ($sql_connection);