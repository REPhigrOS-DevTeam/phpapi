<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$WDK_Web = new WDK_Web;
$WDK_SQL = new WDK_SQL;
$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    $Web_Tools->Jump ("/user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($AccountQueryResult["Level_group"] >= 5)
        {
            if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
            {
                $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
            }
        }
        else
        {
            $Web_Tools->Jump ("/index.php");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}

$SQL_Tools = new SQL_Manage;
$sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

if (isset($_POST["name"]))
{
    $ResultObject = $WDK_SQL->Find_Data (
        $sql_connection,
        "User_Base",
        array(
            "username" => $_POST["name"]
        )
    );
    $Result = $WDK_SQL->Fetch_Assoc ($ResultObject);
    if (count ($Result) != 0)
    {
        $Result = $Result[0];
        if ($Result["MainGroupAccess"] == 1)
        {
            if ($Result["ChannelAccess"] == 0)
            {
                $WDK_SQL->Update_Data (
                    $sql_connection,
                    "User_Base",
                    array(
                        "username" => $_POST["name"]
                    ),
                    array(
                        "ChannelAccess" => 1
                    )
                );

                $Web_Tools->WEBWarn ("用户名：" . $_POST["name"] . "<br>拥有入频权限，可以入频", "审核界面", "/app/admin/shenhe.php");
            }
            else
            {
                $Web_Tools->WEBWarn ("用户名：" . $_POST["name"] . "<br>入频权限已使用过，请不要放人！", "审核界面", "/app/admin/shenhe.php");
            }
        }
        else
        {
            $Web_Tools->WEBWarn ("用户名：" . $_POST["name"] . "<br>没有入频权限", "审核界面", "/app/admin/shenhe.php");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("未查询到此位用户", "审核界面", "/app/admin/shenhe.php");
    }
}
else
{
    $Web_Tools->Jump ("/app/admin/shenhe.php");
}
mysqli_close ($sql_connection);