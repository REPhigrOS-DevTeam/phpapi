<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$WDK_Web = new WDK_Web;
$WDK_SQL = new WDK_SQL;
$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    $Web_Tools->Jump ("/user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($AccountQueryResult["Level_group"] >= 8)
        {
            if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
            {
                $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
            }
        }
        else
        {
            $Web_Tools->Jump ("/index.php");
            exit(0);
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
        exit(0);
    }
}

$SQL_Tools = new SQL_Manage;
$sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

if (isset($_POST["invitename"]))
{
    $WDK_SQL->SendQuery ($sql_connection, "INSERT INTO Record_TestAccessInviteList (UserName, GenerateBy) VALUES ('" . $_POST["invitename"] . "', '" . $_COOKIE["rep_username"] . "')");
    $UpdateResult = $WDK_SQL->Update_Data ($sql_connection, "User_Base", array("username" => $_POST["invitename"]), array("Level_group" => 5));
    $Web_Tools->WEBWarn ("成功，成功添加：<br>新审核名称：" . $_POST["invitename"] . "<br>邀请人：" . $_COOKIE["rep_username"], "审核界面", "/app/admin/shenhe.php");
}
else
{
    $Web_Tools->Jump ("/app/admin/shenhe.php");
}
mysqli_close ($sql_connection);