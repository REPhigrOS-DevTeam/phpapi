<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");

$Web_Tools = new REPhigrOS_WebFunction;

if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
{
    $Web_Tools->Jump ("/user/login");
}
else
{
    $Account_Tools = new REPhigrOS_Account;
    $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
    $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

    if ($AccountQueryResult != false)
    {
        if ($AccountQueryResult["Level_group"] > 0)
        {
            if ($Account_Tools->kickBannedPlayer ($_COOKIE["rep_username"]))
            {
                $Web_Tools->WEBWarn ("您的账户已经被 REPhigrOS 官方永久封禁！", "官网", "//rephigros.top");
            }
        }
        else
        {
            $Web_Tools->Jump ("/index.php");
        }
    }
    else
    {
        $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
    }
}

$SQL_Tools = new SQL_Manage;
$sql_connection = $SQL_Tools->getConnection (1); // 获取 SQL Connection

// 检测 SQL Connection
if ($sql_connection->connect_error)
{
    $Status = false;
}
else
{
    $Status = true;
}

if (isset($_GET["paperid"]))
{
    $sqls = "SELECT * FROM Qs_TestAccess WHERE (PaperID='{$_GET["paperid"]}')";
    $QueryResult = $sql_connection->query ($sqls);
    if ($QueryResult->num_rows > 0)
    { // 检查 Query Result
        $user = $QueryResult->fetch_assoc ();
        // 判断试卷是否开启
        if ($user["opening"] != 1)
        {
            $Web_Tools->WEBWarn ("此试卷被关闭，详情请询问管理组：PaperID:{$_GET["paperid"]}", "审核界面", "/app/admin/shenhe.php");
        }
    }
    else
    {
        $Web_Tools->Jump ("/app/admin/shenhe.php");
    }
}
else
{
    $Web_Tools->Jump ("/app/admin/shenhe.php");
}
?>

<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS 审核页 | 用户</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Large-Box-Content">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">审核</a></div>
        <hr>
        <div class="Content">
            <a class="Text">用户名：
                <?php echo $user["username"]; ?>
            </a><br>
            <?php
            $Array = $user["AnswerJSON"];
            $Array = json_decode ($Array, true);

            $Score = 0;

            if ($Array["Q1"] == "1")
            {
                $Score = $Score + 6.5;
            }
            else
            {
                $Score = $Score - 20;
            }

            if ($Array["Q3"] == "1")
            {
                $Score = $Score + 6.5;
            }
            else
            {
                $Score = $Score - 20;
            }

            if ($Array["Q4"] == "1")
            {
                $Score = $Score + 6.5;
            }
            else
            {
                $Score = $Score - 20;
            }

            if ($Array["Q5"] == "1")
            {
                $Score = $Score + 6.5;
            }
            else
            {
                $Score = $Score - 20;
            }

            if ($Array["Q6"] == "1")
            {
                $Score = $Score + 6.5;
            }
            else
            {
                $Score = $Score - 20;
            }

            if ($Array["Q7"] == "1")
            {
                $Score = $Score + 6.5;
            }
            else
            {
                $Score = $Score - 20;
            }
            if ($Array["Q9"] == "1")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q10"] == "1")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q11"] == "2")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q12"] == "2")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q13"] == "3")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q14"] == "2")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q15"] == "1")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q16"] == "3")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q17"] == "3")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q18"] == "4")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q19"] == "1")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q20"] == "3")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q21"] == "4")
            {
                $Score = $Score + 6.5;
            }
            if ($Array["Q22"] == "4")
            {
                $Score = $Score + 6.5;
            }
            ?>
            <a class="Text">选择题分数：
                <?php echo $Score; ?>
            </a><br>
            <a class="Text">答题1（15分）：
                <?php echo $Array["Q2"]; ?>
            </a><br><a style="color: red;">（注意，本道题只需要说：“清楚” 或 “明白”之类的话 就算过）<br><br></a>
            <a class="Text">答题2（15分）：
                <?php echo $Array["Q8"]; ?> （答案：15.9）
            </a><br>
            <a class="Button"
                href="/app/admin/controler/ChangePaper.php?paperid=<?php echo $_GET["paperid"]; ?>&agree=true">通过</a>
            <a class="Button"
                href="/app/admin/controler/ChangePaper.php?paperid=<?php echo $_GET["paperid"]; ?>&agree=false">不通过</a>
        </div>
    </section>

    <div class="Head-Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
</body>

<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>