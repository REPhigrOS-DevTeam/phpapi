<?php
if (!isset($_GET["reason"], $_GET["buttontext"], $_GET["callback"])) {
    header("location: /index.php");
}
?>



<!doctype html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="//cdn.atomunite.cn/rephigros/image/webicon.png">
    <title>REPhigrOS | 提示</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//cdn.atomunite.cn/rephigros/css/main.css">
</head>

<body>
    <div class="Background"></div>
    <div class="Loader" id="loader" style="width: 0%;"></div>
    <section class="Box">
        <div><a class="Title">REPhigrOS</a><a class="SubTitle">提示</a></div>
        <hr>

        <div class="Content">
            <a class="Text"><?php echo $_GET["reason"]; ?></a><br>
            <a class="Button" href="<?php echo $_GET["callback"]; ?>">返回<?php echo $_GET["buttontext"]; ?></a>
        </div>
    </section>
    <div class="Copyright">
        <a>© 2023 REPhigrOS Team All rights reserved.</a>
    </div>
</body>
<script src="/static/js/main.js"></script>
<script src="/static/js/account.js"></script>

</html>