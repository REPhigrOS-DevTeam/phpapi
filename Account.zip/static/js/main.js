document.onreadystatechange = function () {
    if (document.readyState == "uninitalized") {
        document.getElementById("loader").style.width = "10%"
    }
    if (document.readyState == "loading") {
        document.getElementById("loader").style.width = "40%"
    }
    if (document.readyState == "interactive") {
        document.getElementById("loader").style.width = "60%"
    }
    if (document.readyState == "complete") {
        document.getElementById("loader").style.width = "100%"
    }
}