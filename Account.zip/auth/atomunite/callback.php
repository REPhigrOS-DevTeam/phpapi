<?php
require("/www/wwwroot/WebSpace/PHP/system.function.php");
require("/www/wwwroot/WebSpace/PHP/wdk-atomunite.php");

$Web_Tools = new REPhigrOS_WebFunction;
$WDK_SQL = new WDK_SQL;

$sql_connection = $WDK_SQL->GetConnection ();

if (isset($_POST["Name"], $_POST["AccessToken"]))
{
    if (! isset($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]))
    {
        header ("location: /user/login");
    }
    else
    {
        $Account_Tools = new REPhigrOS_Account;
        $AccountQueryResult = $Account_Tools->getAccountUserData ($_COOKIE["rep_username"], $_COOKIE["rep_verifytoken"]);
        $User_TestAccess = $Account_Tools->getAccountAPPToken ($_COOKIE["rep_username"]);

        if ($AccountQueryResult != false)
        {
            $Name = $_POST["Name"];
            $AccessToken = $_POST["AccessToken"];

            $ClientID = "28f33be5";

            $Data = json_decode (file_get_contents ("https://api.atomunite.cn/auth/v1/verification?client_id=$ClientID&Name=$Name&AccessToken=$AccessToken"), true);
            if ($Data["Status"])
            {
                $Data = $Data["Data"];
                $WDK_SQL->Add_Data (
                    $sql_connection,
                    "Auth_AtomUnite",
                    array(
                        "atom_Name" => $Data["UserName"],
                        "rep_Name"  => $_COOKIE["rep_username"]
                    )
                );
                $Web_Tools->WEBWarn ("绑定成功，以后可使用AtomUnite账户直接登录", "面板", "/");
            }
            else
            {
                $Web_Tools->WEBWarn ("校验信息失败", "面板", "/");
            }
        }
        else
        {
            $Web_Tools->WEBWarn ("用户信息错误，或您尚未在发在您邮箱的链接激活账号", "面板", "/");
        }
    }
}
else
{
    $Web_Tools->WEBWarn ("无法获取信息", "面板", "/");
}