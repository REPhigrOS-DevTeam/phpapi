<?php
if (isset($_COOKIE["rep_username"],$_COOKIE["rep_verifytoken"])) {
    header("location: /user/panel");
} else {
    header("location: /user/login");
}
?>